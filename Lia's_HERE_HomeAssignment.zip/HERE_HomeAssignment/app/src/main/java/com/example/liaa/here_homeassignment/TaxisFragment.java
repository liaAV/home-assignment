package com.example.liaa.here_homeassignment;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import android.os.*;


public class TaxisFragment extends Fragment {
    private static ArrayList<CabStation> arrayOfCabs;
    private static TaxisArrayAddapter adapter;
    private View view;
    private ListView taxisListView = null;
    private Runnable mRunnable;
    private Handler mHandler;
    double[] currentLocation = new double[2];
    double[] destinationLocation = new double[2];

    public TaxisFragment() {
        arrayOfCabs = new ArrayList<CabStation>();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        currentLocation = bundle.getDoubleArray(LocationFragment.CURRENT_LOCATION_KEY);
        destinationLocation = bundle.getDoubleArray(LocationFragment.DESTINATION_LOCATION_KEY);

        initializeParametrs(inflater, container);
        setDataToListView();

        return view;
    }

    private void initializeParametrs(LayoutInflater inflater, ViewGroup container){
        view = inflater.inflate(R.layout.fragment_taxis, container, false);
        taxisListView = (ListView)view.findViewById(R.id.taxis_listView);
        adapter = new TaxisArrayAddapter(getActivity(),arrayOfCabs);
        taxisListView.setAdapter(adapter);
    }

    /**
     * Set data with new random ETA every 5 seconds
     */
    private void setDataToListView(){
        mRunnable = new Runnable() {
            @Override
            public void run() {
                if (!arrayOfCabs.isEmpty()) arrayOfCabs.clear();
                    setDataToCabsArray();
                    Collections.sort(arrayOfCabs, Sorter);
                    adapter.notifyDataSetChanged();
                    mHandler.postDelayed(this, 5000);
            }
        };
        mHandler = new Handler();
        mHandler.post(mRunnable);
    }

    /**
     * Fill array af cabs
     */
    private void setDataToCabsArray(){
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.red_cab) ,
                getResources().getString(R.string.castle_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.blue_cab) ,
                getResources().getString(R.string.shekem_cab) ,getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.black_cab),
                getResources().getString(R.string.habima_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.green_cab),
                getResources().getString(R.string.gordon_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.grey_cab),
                getResources().getString(R.string.azrieli_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.orange_cab),
                getResources().getString(R.string.alembi_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.purple_cab),
                getResources().getString(R.string.florentin_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.light_blue_cab),
                getResources().getString(R.string.ramat_gan_cab),getRandomETA()) );
        arrayOfCabs.add(new CabStation(getResources().getDrawable(R.drawable.purple_cab),
                getResources().getString(R.string.rotshild_cab),getRandomETA()) );
    }

    /**
     * Get random ETA to each cab
     * @return ETA AS int
     */
    private int getRandomETA(){
        int upper_bound = 5000;
        int low_bound = 60;
        Random rnd = new Random();
        return rnd.nextInt(upper_bound-low_bound)+low_bound;
    }

    /**
     * Convert milliseconds to hours and minutes
     * @param milliseconds
     * @return Formated string of time
     */
    public String convertIntToTime(int milliseconds){
         int minutesInHour = 60;
         int secondInMinute= 60;
         int hours = milliseconds/(minutesInHour*secondInMinute);
         int remainder =  milliseconds - hours * minutesInHour * secondInMinute;
         int mins = remainder / secondInMinute;

         if (hours == 0 ) return String.format("%2dm",  mins);
         else if (mins == 0 ) return String.format("%2dh",  hours);
         else return String.format("%2dh:%2dm", hours, mins);
    }

    /**
     * Comparator to sort listView by ETA
     */
    public static Comparator<CabStation> Sorter  = new  Comparator<CabStation>(){
        int order = -1;
        @Override
        public int compare(CabStation o1, CabStation o2) {
            if(o1.cabETA - o2.cabETA == 0) return 0;
            else if (o1.cabETA - o2.cabETA < 0) return order;
            else return -1*order;
        };
    };

    /**
     * Custom ArrayAdapter
     */
  public class TaxisArrayAddapter extends ArrayAdapter<CabStation>{

      public TaxisArrayAddapter(Context context, ArrayList<CabStation> users) {
          super(context, 0, users);
      }

      @Override
      public View getView(int position, View convertView, ViewGroup parent) {
          SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss");
          CabStation cabStation = getItem(position);

          if (convertView == null) {
              convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_taxi, parent, false);
          }
          if(convertView!=null) {
              ImageView cabImage = (ImageView) convertView.findViewById(R.id.itemImage);
              TextView cabName = (TextView) convertView.findViewById(R.id.itemName);
              TextView cabETA = (TextView) convertView.findViewById(R.id.itemETA);

              cabName.setText(cabStation.getCabName());
              cabImage.setImageDrawable(cabStation.getCabImage());
              cabETA.setText(convertIntToTime(cabStation.getCabETA()));
          }
          return convertView;
      }
  }

    @Override
    public void onDestroy() {
        mHandler.removeCallbacks(mRunnable);
        super.onDestroy();
    }

}
