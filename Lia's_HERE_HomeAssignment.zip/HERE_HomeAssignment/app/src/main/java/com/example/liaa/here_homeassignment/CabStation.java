package com.example.liaa.here_homeassignment;

import android.graphics.drawable.Drawable;

/**
 * Created by liaa on 25/03/2018.
 */
public class CabStation {
    Drawable cabImage;
    String cabName;
    int cabETA;

    public CabStation(Drawable cabImage, String cabName, Integer cabETA) {
        this.cabImage = cabImage;
        this.cabName = cabName;
        this.cabETA = cabETA;
    }

    public Drawable getCabImage() {
        return cabImage;
    }

    public void setCabImage(Drawable cabImage) {
        this.cabImage = cabImage;
    }

    public String getCabName() {
        return cabName;
    }

    public void setCabName(String cabName) {
        this.cabName = cabName;
    }

    public Integer getCabETA() {
        return cabETA;
    }

    public void setCabETA(Integer cabETA) {
        this.cabETA = cabETA;
    }
}
