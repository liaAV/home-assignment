package com.example.liaa.here_homeassignment;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.GridLayout.LayoutParams;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import static android.view.View.OnFocusChangeListener;


/**
 * A simple {@link Fragment} subclass.
 */
public class LocationFragment extends Fragment  implements LocationListener {
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 1;
    public static final String CURRENT_LOCATION_KEY = "currentLocationKey";
    public static final String DESTINATION_LOCATION_KEY = "destinationLocationKey";
    private Button search_button;
    private View rootView;
    private double latitude;
    private double longitude;
    private double desLatitude;
    private double desLongitude;
    private  Location location;
    private String locationFragmentTag ="LocationFragmentTag";
    private boolean isGPSEnabled = false;
    private boolean isNetworkEnabled = false;
    private boolean canGetLocation = false;
    private EditText destinationLocationEditText;
    private EditText currentLocationEditText;
    protected LocationManager locationManager;

    public LocationFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_location, container, false);

        initializeParameters();
        getCurrentLocation();
        setCurrentLocation();

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(isAllFieldsEntered()){
                        hideSoftKeyboard(getActivity());
                        getDestinationLocation();
                        callToTaxisListFragment();
                    }

            }
        });
        return rootView;
    }

    private void initializeParameters(){
        search_button = rootView.findViewById(R.id.search_button);
        destinationLocationEditText = rootView.findViewById(R.id.destination_location);
        currentLocationEditText = rootView.findViewById(R.id.current_location);
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

    }

    /**
     *
     * @return true - Current location and Destination location not empty
     *         false- Current location and Destination location is empty
     */
    private boolean isAllFieldsEntered(){
        boolean isCurrentLocationEmpty = currentLocationEditText.getText().toString().isEmpty();
        boolean isDestinationLocationEmpty = destinationLocationEditText.getText().toString().isEmpty();

        if(isCurrentLocationEmpty){
            TextInputLayout tilC = (TextInputLayout) rootView.findViewById(R.id.textCurrentInputLayout);
            tilC.setErrorEnabled(true);
            tilC.setError(getResources().getString(R.string.helper_current_location));
        }

        if(isDestinationLocationEmpty) {
            TextInputLayout tilD = (TextInputLayout) rootView.findViewById(R.id.textDestinationInputLayout);
            tilD.setErrorEnabled(true);
            tilD.setError(getResources().getString(R.string.helper_destination_location));
        }

        return !isCurrentLocationEmpty && !isDestinationLocationEmpty;
    }

    /**
     * Call to TaxisFragment with cubs listView
     */
    private void callToTaxisListFragment(){
        double[] currentLocationData = {latitude,longitude};
        double[] destinationLocationData = {desLatitude,desLongitude};

        Bundle bundle = new Bundle();
        bundle.putDoubleArray(CURRENT_LOCATION_KEY,currentLocationData);
        bundle.putDoubleArray(DESTINATION_LOCATION_KEY,destinationLocationData);

        TaxisFragment locationFragment = new TaxisFragment();
        locationFragment.setArguments(bundle);
        getFragmentManager().beginTransaction()
                .replace(R.id.fragment_layout,locationFragment,locationFragmentTag)
                .addToBackStack(MainActivity.LOCATION_FRAGMENT_TAG)
                .commit();

    }

    /**
     * Get Latitude and Longitude by destination address
     */
    private void getDestinationLocation(){
        Geocoder coder = new Geocoder(getActivity());
        List<Address> address;

        String destinationAddressText = destinationLocationEditText.getText().toString();

            try {
                address = coder.getFromLocationName(destinationAddressText, 20);Address location=address.get(0);
                desLatitude = location.getLatitude();
                desLongitude =location.getLongitude();

            }catch (Exception e){
                Log.e("Exception",e.getMessage());
                desLatitude =0;
                desLongitude =0;
            }
    }

    /**
     * Set address of current location by latitude and longitude
     */
    private void setCurrentLocation(){
            EditText currentLocationEditText = (EditText) rootView.findViewById(R.id.current_location);
            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(getActivity(), Locale.getDefault());
            try {
                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                String address = addresses.get(0).getAddressLine(0);
                currentLocationEditText.setText(address);
            } catch (Exception exeption) {
                   Log.e("GetAddressCurrentLoc", exeption.getMessage());
            }
    }

    /**
     * Get Latitude and Longitude of current location by GPS/NETWORK
     */
    public void getCurrentLocation(){
        try {
            locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

            isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if (!isGPSEnabled && !isNetworkEnabled)
                Toast.makeText(getActivity(), R.string.no_service_rovider_is_available, Toast.LENGTH_SHORT).show();

            if (isGPSEnabled) {
                canGetLocation = true;
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        MIN_TIME_BW_UPDATES,
                        MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                if (locationManager != null) {
                    location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (location != null) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                    }
                }

            } else if (isNetworkEnabled) {
                canGetLocation = true;
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        MIN_TIME_BW_UPDATES,
                        MIN_DISTANCE_CHANGE_FOR_UPDATES, this);

                if (locationManager != null) {
                    location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }

                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }
            }
        }catch (SecurityException exeption){}
    }

    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }
}
