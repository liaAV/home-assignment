package com.example.liaa.here_homeassignment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseIntArray;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity{
    private static final int REQUEST_PERMISSION = 10;
    public static final  String LOCATION_FRAGMENT_TAG = "TaxiFragment";
    private boolean backFromSettingWindow = false;
    private static SparseIntArray mErrorString;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);
        mErrorString = new SparseIntArray();
        requestAppPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, R.string.msg_location_permission ,REQUEST_PERMISSION);
    }

    /**
     * Runtime request permissions
     * @param requestedPermissions Array of permission
     * @param stringId  String that will be shown to user
     * @param requestCode requestCode
     */
    public   void requestAppPermissions(final String[] requestedPermissions, final int stringId, final int requestCode){
        mErrorString.put(requestCode, stringId);
        int permissionCheck = PackageManager.PERMISSION_GRANTED;
        boolean showRequestPermissions = false;

        for(String permission:requestedPermissions){
            permissionCheck = permissionCheck + ContextCompat.checkSelfPermission(this , permission);
            showRequestPermissions = showRequestPermissions||
                    ActivityCompat.shouldShowRequestPermissionRationale(this,permission);
        }

        if (permissionCheck!=PackageManager.PERMISSION_GRANTED){
            if(showRequestPermissions){
                Snackbar.make(this.findViewById(android.R.id.content),stringId,Snackbar.LENGTH_INDEFINITE).setAction("Grant", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ActivityCompat.requestPermissions(MainActivity.this,requestedPermissions,requestCode);

                    }
                }).show();
            }else {
                 ActivityCompat.requestPermissions(this,requestedPermissions,requestCode);
            }

        }else{
            onPermissionGranted(requestCode);

        }
    }

    public void onPermissionGranted(int reqrestCode) {
         Toast.makeText(getApplicationContext(),"Permission Granted",Toast.LENGTH_LONG).show();
         LocationFragment taxisFragment= new LocationFragment();
         getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, taxisFragment, LOCATION_FRAGMENT_TAG)
                 .commit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        int permissionCheck = PackageManager.PERMISSION_GRANTED;

        for(int permission:grantResults){
            permissionCheck = permissionCheck + permission;
        }

        if((grantResults.length>0) && PackageManager.PERMISSION_GRANTED == permissionCheck){
             onPermissionGranted(requestCode);

        } else {
            Snackbar.make(this.findViewById(android.R.id.content),mErrorString.get(requestCode),Snackbar.LENGTH_INDEFINITE).
                    setAction("ENABLE", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            backFromSettingWindow = true;
                            Intent i = new Intent();
                            i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            i.setData(Uri.parse("package:"+getPackageName()));
                            i.addCategory(Intent.CATEGORY_DEFAULT);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                            i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                            startActivity(i);
                        }
                    }).show();
        }

    }


    @Override
    protected void onResume() {
        super.onResume();
        if(backFromSettingWindow) {
            requestAppPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, R.string.msg_location_permission, REQUEST_PERMISSION);
            backFromSettingWindow = false;
       }
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().findFragmentByTag(LOCATION_FRAGMENT_TAG) != null){
           getFragmentManager().popBackStackImmediate(LOCATION_FRAGMENT_TAG,0);
        } else {
            super.onBackPressed();
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }

}
